import com.capgemini.beans.Animal;
import com.capgemini.beans.Cat;
import com.capgemini.beans.Feline;
import com.capgemini.beans.Pet;

public class Entry {

	public static void main(String[] args) {
		
		Animal animalRef;
		
//		animalRef = new Animal();
		
//		IMPLICIT UP-CASTING
		animalRef = (Animal)new Cat();
		
		animalRef.eat();
		animalRef.sleep();
		animalRef.roam();
		
//		animalRef.meow();
		
//		EXPLICIT DOWN-CASTING
		Cat catRef = (Cat)animalRef;
		
		catRef.meow();
		System.out.println(Feline.MAX++);
		
		
		
		Animal animalRef2 = getAnimal();
		
		boolean flag = (animalRef2 instanceof Pet);

		Pet petRef =null;
		if(flag == true){
			petRef = (Pet)animalRef2;
			
			petRef.beFriendly();
			petRef.play();
		}else{
			System.out.println("We did not find Pet");
		}
		
		
		String petName = new String("Tommy");
		
//		petRef =(Pet) petName;
		
		
		
		System.out.println(Pet.MAX);
		
//		System.out.println(Pet.MAX++);
		
	}
	
	
	
	public static Animal getAnimal(){
		
		return new Cat();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
