package com.capgemini.beans;

import java.io.Serializable;

public /*abstract */interface Pet {

	
	/*abstract */void beFriendly();
	abstract void play();
	
	/*public static final */int MAX = 20;
}
