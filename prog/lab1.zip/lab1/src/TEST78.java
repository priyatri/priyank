
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TEST78 {

	
	
	
		public static void main(String[] args) throws ParseException
		{
			priyam55555 ob1=new priyam55555("priyam","tripathi",45673,567,"04/12/2018");
			SimpleDateFormat d= new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat d1= new SimpleDateFormat("MMM-yyyy");
			String ad= ob1.getJoining();
			Date date= d.parse(ad);
			String add=d1.format(date);
			

			System.out.println(ob1.getName1());
			System.out.println(ob1.getName2());
			
			System.out.println(ob1.getSalary());
			
			System.out.println(ob1.getGrade());
			System.out.println(ob1.getEmpn());
			
			System.out.println(add);
			
			
			priyam55555 ob2=new priyam55555("priam","tripai",45585873,56897,"04/02/2018");
			SimpleDateFormat d5= new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat d6= new SimpleDateFormat("MMM-yyyy");
			String ade= ob2.getJoining();
			Date dae= d5.parse(ade);
			String adg=d6.format(dae);
			
			
			System.out.println(ob2.getName1());
			System.out.println(ob2.getName2());
			
			System.out.println(ob2.getSalary());
			
			System.out.println(ob2.getGrade());
			System.out.println(ob2.getEmpn());
			
			System.out.println(adg);
		}
	}

	
	
	
	
