package com.capgemini.beans;

public class Technical_Associate extends Permanent_Employee {
	
	public Technical_Associate(String fname, String lname, double salary, Date doj)
	{
		super(fname, lname, salary, doj);
		super.getClaimref().setCoverageammount(this.getSalary()*2);
	}
	
	/* public Mediclaim getClaimref() {
		Mediclaim claimref=new Mediclaim(this.getSalary()*2);
		return claimref ;*/
	}

		

	
