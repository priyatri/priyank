package com.capgemini.beans;

public abstract class Animal {

	public abstract void sleep();

	public abstract void eat();

	public abstract void roam();

}
