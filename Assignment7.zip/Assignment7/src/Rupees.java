
public class Rupees extends Currency 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Rupees(double a) {
		super(a);
	
	} 
  
} 
  