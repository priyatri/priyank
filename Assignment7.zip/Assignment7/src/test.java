import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class test {
public static void main(String[] args) {
	
   double rs=0;
   double doll=0;
   Currency object1 = null; 
    String filename = "file.ser"; 
    // Deserialization 
    try
    {    
        // Reading the object from a file 
        FileInputStream file = new FileInputStream(filename); 
        ObjectInputStream in = new ObjectInputStream(file); 
          
        // Method for deserialization of object 
        object1 = (Currency)in.readObject();
        if(object1 instanceof Rupees) {
        	rs=object1.a;
        	
        }
        else if(object1 instanceof Dollar) {
        	doll=object1.a;
        	rs=doll*71.58;
        }
        in.close(); 
        file.close(); 
          
        System.out.println("Object has been deserialized "); 
        System.out.println("Currency in Rupees = " + rs +"Rs.");
       
    } 
      
    catch(IOException ex) 
    { 
        System.out.println("IOException is caught"); 
    } 
      
    catch(ClassNotFoundException ex) 
    { 
        System.out.println("ClassNotFoundException is caught"); 
    } 
}

}