import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class asg7 
{ 
    public static void main(String[] args) 
    {    
        Currency object; 
        String filename = "file.ser"; 
         double a=Math.random();
         System.out.println(a);
         if(a>0.5)
        	 object= new Dollar(1);
         else
        	 object= new Rupees(100.0);
        // Serialization  
        try
        {    
            //Saving of object in a file 
            FileOutputStream file = new FileOutputStream(filename); 
            ObjectOutputStream out = new ObjectOutputStream(file); 
              
            // Method for serialization of object 
            out.writeObject(object); 
              
            out.close(); 
            file.close(); 
              
            System.out.println("Object has been serialized"); 
  
        } 
          
        catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
  
  
  
    } 
} 