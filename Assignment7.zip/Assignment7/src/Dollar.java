
public class Dollar extends Currency 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Dollar(double a) {
		super(a);
	
	} 
  
} 
  