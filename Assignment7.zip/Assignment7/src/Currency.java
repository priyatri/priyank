
public class Currency implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	double a;

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public Currency(double a) {
		this.a = a;
	}
	

}
