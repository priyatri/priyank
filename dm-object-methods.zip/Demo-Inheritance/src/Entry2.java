import com.capgemini.beans.Cat;

public class Entry2 {
	public static void main(String[] args) {
		
		Cat catRef = new Cat("Tiger");
		Cat catRef2 = new Cat("Babli");
		
//		catRef2 = catRef;
		
		System.out.println(catRef);
		System.out.println(catRef.toString());
		
		boolean flag = catRef.equals(catRef2);
		
		System.out.println(flag);
		
//		catRef = null;
//		catRef2 = null;
		
		System.gc();
	}
}
