package com.capgemini.beans;

public class Cat extends Feline implements Pet {
	private String name;

	public Cat() {
		// TODO Auto-generated constructor stub
	}

	public Cat(String name) {
		// TODO Auto-generated constructor stub
		this.name = name;
	}

	@Override
	public boolean equals(Object obj) {
		boolean flag = false;

		if (this == obj)
			return true;

		flag = !(obj instanceof Cat);
		if (flag)
			return false;

		flag = this.name.equals(((Cat) obj).name);

		return flag;
	}

	@Override
	protected void finalize() throws Throwable {
		System.out.println("cleaning up Cat with name " + name);
		super.finalize();
	}

	@Override
	public String toString() {
		return "I'm a Cat";
	}

	// @Override
	public void beFriendly() {
		// TODO Auto-generated method stub
		System.out.println("I'm friendly");
	}

	// @Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("You can play with me");
	}

	/*
	 * public void roam(){ System.out.println("It roams alone"); }
	 */

	@Override
	public void eat() {
		System.out.println("I drink milk");
	}

	@Override
	public void sleep() {
		System.out.println("I sleep in litter box");
	}

	public void meow() {
		System.out.println("It meows");
	}

}
