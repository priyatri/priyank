package com.capgemini.beans;

public /*final*/ abstract class Animal {

	public abstract void sleep();

	public abstract void eat();

	public abstract void roam();

}
