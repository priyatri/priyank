package com.capgemini.beans;

public abstract class Feline extends Animal{

	public static int MAX;
	
	public final void roam(){
		System.out.println("It roams alone");
	}
	
	
}
