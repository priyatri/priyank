import com.capgemini.beans.Account;

public class Entry2 {
	public static void main(String[] args) throws InterruptedException {
		
		Account sharedAccount = new Account(5000, 1);
		Account sharedAccount2 = new Account(5000, 2);
		
		Thread t1 = new DepositThread(sharedAccount);
		t1.start();
				
		Thread t2 = new WithdrawThread(sharedAccount);
		t2.start();
		
		t1.join();
		t2.join();
		
		
		System.out.println("Balance in "+ sharedAccount + ": "+ sharedAccount.getBalance());
		System.out.println("Balance in "+ sharedAccount2 + ": "+ sharedAccount2.getBalance());
		
		
	} 
	
}
