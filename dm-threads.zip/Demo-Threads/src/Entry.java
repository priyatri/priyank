
public class Entry {
	public static void main(String[] args) {
		
		Thread t1 = new OddNumbersThread();
		t1.start();

		
		Thread t2 = new EvenNumbersThread();
		t2.start();

		
		System.out.println("end of main()...");
		
	}
}
