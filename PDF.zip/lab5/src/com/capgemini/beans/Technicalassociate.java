
package com.capgemini.beans;

public class Technicalassociate extends Permanentemployee {
	int x;
	int z;
	
	public Technicalassociate(String fname, String lname, double salary, Date doj, int x, int z)
	{
		super(fname, lname, salary, doj);
		
		this.x = x;
		this.z = z;
		setSalary(0);
	}
	public Mediclaim getClaimref()
	{
		Mediclaim claimref=new Mediclaim(this.getSalary()*2);
		return claimref ;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getZ() {
		return z;
	}
	public void setZ(int z) {
		this.z = z;
	}
	public void setSalary(double salary) {
		salary=5000*this.getX()+1000*this.getZ();
		super.setSalary(salary);
		}	
}
		

		
