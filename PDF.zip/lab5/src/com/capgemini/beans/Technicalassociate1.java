package com.capgemini.beans;

public class Technicalassociate1 extends Contractbasedemployee {
	int hours;
	
public Technicalassociate1(String fname, String lname, double salary, Date doj, int hours) {
		super(fname, lname, salary*hours,doj );
		
}
public Mediclaim getclaimref()
{
	Mediclaim m= new Mediclaim(this.getsalary());
	return m;
}
public double getsalary()
{
	return salary;
}
public void setsalary(double salary)
{
	this.salary=salary;
	
}
public void setSalary()
{
	if(hours<=40)
	{
		salary=salary*hours;
		super.setSalary();
	}
	else if(hours>40)
	{
		salary=40*salary+(hours-40)*salary*2;
		super.setSalary();
	}
	return;
	}
}



