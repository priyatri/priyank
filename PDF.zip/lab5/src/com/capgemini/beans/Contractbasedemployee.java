package com.capgemini.beans;

public class Contractbasedemployee extends Employee {


	public Contractbasedemployee(String fname, String lname, double salary, Date doj) {
		super(fname, lname, salary, doj);
		
		
		
	}
	
	

	








	public void setSalary() {
	
		
	}
	
	
}
