package com.capgemini.beans;

public class Projectmanager extends Permanentemployee  {
	int y;
	public Projectmanager(String fname, String lname, double salary, Date doj, int y)
	{
		super(fname,lname,salary,doj);
		this.y=y;
		setSalary(0);
	}
	
	public Mediclaim getClaimref()
	{
		Mediclaim claimref=new Mediclaim(this.getSalary());
		return claimref ;
	}

	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void setSalary(double salary) {
	salary=10000*this.getY();
	super.setSalary(salary);
	}	
	
}
