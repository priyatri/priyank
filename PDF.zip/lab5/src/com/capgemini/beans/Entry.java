package com.capgemini.beans;

public class Entry

{
	public static void main(String[] args)
	{
		Date d= new Date(26,06,2018);
	
		
	/*	Contract_Based_Employee ob1= new Contract_Based_Employee("Priya","Singh",0.0,d,7,c);
		System.out.println(ob1.getFName());
		System.out.println(ob1.getSalary());
		System.out.println(ob1.contractor.getName());
		System.out.println(ob1.doj.display());
		
		Permanent_Employee ob2= new Permanent_Employee("Shivi","Sinha",25000.0,d);
        System.out.println(ob2.getFName());
		System.out.println(ob2.getSalary());
		System.out.println(ob2.doj.display());
		*/
		Date l= new Date(26,06,2018);
				Projectmanager ob3= new Projectmanager("Rishi","Raj", 34000.0,l, 5);
				System.out.println(ob3.getFName());
				System.out.println(ob3.getLName());
				System.out.println(ob3.getSalary());
				System.out.println(ob3.doj.display());
			   System.out.println(ob3.getClaimref().getCoverageammount());
				
				Date g= new Date(25,06,2018);
				Technicalassociate ob4=new Technicalassociate("Preeti","Sharma",45000.0,g,8,9);
				System.out.println(ob4.getFName());
				System.out.println(ob4.getLName());
				System.out.println(ob4.getSalary());
				System.out.println(ob4.doj.display());
				System.out.println(ob4.getClaimref().getCoverageammount());
	
				Date h= new Date(22,02,2014);
				Technicalassociate1 ob5=new Technicalassociate1("shubham","tiwari",56000.0,h,6);
				System.out.println(ob5.getFName());
				System.out.println(ob5.getLName());
				System.out.println(ob5.getsalary());
				System.out.println(ob5.doj.display());
				System.out.println(ob5.getclaimref().getCoverageammount());
				

	
}
}
