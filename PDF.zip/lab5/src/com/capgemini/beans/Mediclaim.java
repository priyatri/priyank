package com.capgemini.beans;

public class Mediclaim {

	double coverageammount;

	public Mediclaim(double coverageammount) {
		this.coverageammount = coverageammount;
	}

	public double getCoverageammount() {
		return coverageammount;
	}

	public void setCoverageammount(double coverageammount) {
		this.coverageammount = coverageammount;
	}

}
