package com.capgemini.beans;


	

public abstract class Permanentemployee extends Employee {
	
	Mediclaim claimref=new Mediclaim(0);
	
	public Permanentemployee(String fname, String lname, double salary, Date doj) {
		super(fname, lname, salary,doj);
		
		
	}

	public Mediclaim getClaimref() {
		return claimref;
	}

	

}

