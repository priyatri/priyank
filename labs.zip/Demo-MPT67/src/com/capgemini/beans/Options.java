package com.capgemini.beans;

public enum Options {
	
	
	byid, byName;

}
